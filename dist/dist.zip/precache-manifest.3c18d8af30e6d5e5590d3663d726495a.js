self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/js/chunk-vendors.e1c48d6f.js"
  },
  {
    "revision": "bbd782e260d16d7947c6",
    "url": "/js/app.7e9afd44.js"
  },
  {
    "revision": "395dad21fce3070170e3d0803db3f5a3",
    "url": "/index.html"
  },
  {
    "revision": "32c5d83d08fa95d78bea70aaa20a3530",
    "url": "/favicon.png"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/css/chunk-vendors.ee7084df.css"
  },
  {
    "revision": "bbd782e260d16d7947c6",
    "url": "/css/app.c9959beb.css"
  }
];