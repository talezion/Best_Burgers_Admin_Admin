self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/js/chunk-vendors.e1c48d6f.js"
  },
  {
    "revision": "cf584c540b635553296e",
    "url": "/js/app.8e8cd193.js"
  },
  {
    "revision": "7afd2006431ac271a8177ac52620f1f6",
    "url": "/index.html"
  },
  {
    "revision": "32c5d83d08fa95d78bea70aaa20a3530",
    "url": "/favicon.png"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/css/chunk-vendors.ee7084df.css"
  },
  {
    "revision": "cf584c540b635553296e",
    "url": "/css/app.921212c5.css"
  }
];