self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/js/chunk-vendors.e1c48d6f.js"
  },
  {
    "revision": "fdded34f0d2e07ff4f74",
    "url": "/js/app.566f3502.js"
  },
  {
    "revision": "1c13865a222325ebed61da0c10591283",
    "url": "/index.html"
  },
  {
    "revision": "32c5d83d08fa95d78bea70aaa20a3530",
    "url": "/favicon.png"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/css/chunk-vendors.ee7084df.css"
  },
  {
    "revision": "fdded34f0d2e07ff4f74",
    "url": "/css/app.ccf6f6e3.css"
  }
];