self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/js/chunk-vendors.e1c48d6f.js"
  },
  {
    "revision": "c60d6bcb5213adff17e4",
    "url": "/js/app.540eddba.js"
  },
  {
    "revision": "9c98118fc4c35cf1e1a61ddf038d5485",
    "url": "/index.html"
  },
  {
    "revision": "32c5d83d08fa95d78bea70aaa20a3530",
    "url": "/favicon.png"
  },
  {
    "revision": "21b48f50cc156ab2b86b",
    "url": "/css/chunk-vendors.ee7084df.css"
  },
  {
    "revision": "c60d6bcb5213adff17e4",
    "url": "/css/app.ff9f52d6.css"
  }
];